AMSTELHAEGE

team $HabboHotel

Maarten Hogeweij, Julia Jansen, Maarten Brijker

 
Instructies voor het runnen van de code:

Vul in de file amstelhaege.cfg waardes in om mee te runnen. Als default zijn er door ons al waardes ingevuld.

Run main.py om de code uit te voeren.
